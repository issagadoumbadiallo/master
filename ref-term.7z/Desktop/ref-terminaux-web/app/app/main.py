#!/usr/bin/env python3
# -*- coding:utf-8 -*-

import os, json
from functools import wraps
from flask import Flask, send_from_directory, g, session, redirect, url_for

app = Flask(__name__, instance_relative_config=True)


@app.route('/healthcheck')
def healthcheck():
	return 'healthcheck!'
	
def create_app(test_config=None):
    # create and configure the app
    with open('s3_credentials.json') as f:
        s3file=json.load(f)
    app.config.from_mapping(
        SECRET_KEY='dev',
        UPLOAD_FOLDER='app/programmes',
        S3_CREDENTIALS=s3file
    )

    if test_config is None:
        # load the instance config, if it exists, when not testing
        app.config.from_pyfile('config.py', silent=True)
    else:
        # load the test config if passed in
        app.config.from_mapping(test_config)

    # ensure the instance folder exists
    try:
        os.makedirs(app.instance_path)
    except OSError:
        pass
    
    from . import index
    app.register_blueprint(index.bp)
    app.add_url_rule('/', endpoint="index")

    from . import upload
    app.register_blueprint(upload.bp)
    app.add_url_rule('/upload/', endpoint="upload")

    from . import api
    app.register_blueprint(api.bp)
    app.add_url_rule('/api/', endpoint="api")

    from . import auth
    app.register_blueprint(auth.bp)
    app.add_url_rule('/auth/', endpoint="auth")

    @app.route('/favicon.ico')
    def favicon():
        return send_from_directory(os.path.join(app.root_path, 'static'),
                            'favicon.ico',mimetype='image/vnd.microsoft.icon')

    return app

if __name__ == "__main__":
    app.run()
