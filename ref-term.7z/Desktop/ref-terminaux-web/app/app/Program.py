import csv, datetime, os, collections, re
from flask import current_app, jsonify
from copy import deepcopy
from . import ProgramFile
from boto3.session import Session

# Classe qui représente le contenu des fichiers CSV sous forme d'objet

class Program:
    # Constructeur qui prend un objet ProgramFile en entrée
    #def __init__(self, path=None, program_file=None):
    def __init__(self, source_file=None, program_file=None):
        self.init_header()
        self.data = {}
        self.program_file = program_file
        parsingDates = False
        #if path!=None and program_file!=None:
        if source_file!=None:
            #with open(os.path.join(path, program_file.filename), 'r') as f:
            if True:
                #reader = csv.reader(source_file,delimiter=';')
                reader = source_file.splitlines()
                for line in reader:
                    row = str(line, "ansi").split(";")
                    if parsingDates==True:
                        if row[0].startswith('Total'):
                            parsingDates = False
                            self.total = row
                        else:
                            # Data est un champ qui représente le tableau de données
                            # Dictionnaire où la clef est la date sous le format YYYYMMDD
                            # Ce format permet de trier facilement les lignes alphabetiquement
                            # La valeur est un autre dictionnaire
                            d = re.match('([0-9]{2})/([0-9]{2})/([0-9]{4})', row[0])
                            if d:
                                key = d.group(3)+d.group(2)+d.group(1)
                                self.data[key] = {
                                    # Journée gazière
                                    'date':row[0],
                                    # Energie journalière contractuelle programmée à l'émission (kWh/j à 25°C)
                                    'daily_energy':row[1],
                                    # Volume journalier de gaz programmé à l'émission (m³ (n)/j)
                                    'daily_gaz_volume':row[2],
                                    # Volume horaire moyen de gaz programmé à l'émission (m³ (n)/h)
                                    'hourly_gaz_volume':row[3],
                                    # PCS (kWh/m³(n)) 
                                    'pcs':row[4],
                                    # Volume journalier de GNL programmé à l'émission (m³ GNL/j)
                                    'daily_gnl_volume':row[5],
                                    # Volume horaire moyen de GNL programmé à l'émission (m³ GNL/h)
                                    'hourly_gnl_volume':row[6],
                                    # Débit Quotidien Ferme (m³ GNL/h) 
                                    'daily_flow':row[7],
                                    # Stock physique à 06h00 (m³ GNL) 
                                    'stock':row[8],
                                    # Rattrapage OBA programmée avec GRTgaz (kWh/j à 25°C)
                                    'oba_catchup':row[9],
                                    # Nom du navire 
                                    'boat_name':row[10],
                                    # Trigramme du navire
                                    'trigram':row[11],
                                    # Référence du contrat client
                                    'client_reference':row[12],
                                    
                                    # Livraison prévue ou non (champ rajouté déduit des autres données)
                                    # 'delivery':row[12] != "" ? "1":""
                                    
                                    # Origine de la cargaison
                                    'origin':row[13],
                                    # Volume estimé de la cargaison (m³ GNL)
                                    'estimated_volume':int(row[14]) if row[14]!="" else 0,
                                    # Type Cargaison
                                    'type':row[15],
                                    # ETA
                                    'eta':row[16],
                                    # Commentaires
                                    'comments':row[17]
                                }
                    else:
                        if row[0].startswith('Terminal'):
                            self.terminal = row[1]
                        elif row[0].startswith('Période'):
                            self.period = row[1]
                            # Eventuellement parser les dates
                        elif row[0].startswith('Comentaire'):
                            self.comment = row[1]
                        elif row[0].startswith('N° programme physique'):
                            self.program_number = row[1]
                        elif row[0].startswith('Journée gazière'):
                            parsingDates = True
                            self.headers = row

    def init_header(self, terminal="", period="", comment="", program_number=""):
        self.terminal=terminal
        self.period=period
        self.comment=comment
        self.program_number=program_number

    # Si le programme démarre après la date de début ou finit avant la date de fin, on complète le programme avec des lignes vides (juste la date est indiquée)
    def fill_data(self, date1, date2):
        curr = date1
        while curr <= date2:
            key = datetime.datetime.strftime(curr, '%Y%m%d')
            if key not in self.data:
                self.data[key] = init_data_row(date=datetime.datetime.strftime(curr, '%d/%m/%Y'))
            curr += datetime.timedelta(days=1)
    
    # Si le programme a trop de dates par rapport à ce qu'on demande alors on se débarasse des lignes en trop
    def filter_data(self, date1, date2):
        self.data = {k:v for k,v in self.data.items() if date1 <= datetime.datetime.strptime(k, '%Y%m%d') <= date2}

# Initialise une ligne pour le champ data, par défaut vide
def init_data_row(
        date="",
        daily_energy="",
        daily_gaz_volume="",
        hourly_gaz_volume="",
        pcs="",
        daily_gnl_volume="",
        hourly_gnl_volume="",
        daily_flow="",
        stock="",
        oba_catchup="",
        boat_name="",
        trigram="",
        client_reference="",
        origin="",
        estimated_volume=0,
        prog_type="",
        eta="",
        comments=""
        ):
    return {
        'date':date,
        'daily_energy':daily_energy,
        'daily_gaz_volume':daily_gaz_volume,
        'hourly_gaz_volume':hourly_gaz_volume,
        'pcs':pcs,
        'daily_gnl_volume':daily_gnl_volume,
        'hourly_gnl_volume':hourly_gnl_volume,
        'daily_flow':daily_flow,
        'stock':stock,
        'oba_catchup':oba_catchup,
        'boat_name':boat_name,
        'trigram':trigram,
        'client_reference':client_reference,
        'origin':origin,
        'estimated_volume':estimated_volume,
        'type':prog_type,
        'eta':eta,
        'comments':comments
    }

# Renvoie les colonnes de data demandées sous un format spécifique à l'affichage en tableau :
# dates { programmes { champs { valeur } } }
def get_data(programs, *fields):
    data = {}
    for progName,program in programs.items():
        for date,row in program.data.items():
            if not date in data:
                data[date] = {}
            if not progName in data[date]:
                data[date][progName] = {}
            for f in fields:
                data[date][progName][f] = row[f]
    return data

# Renvoie des colonnes additionnelles calculées en fonction des champs existants
# Pour le moment une colonne total_Fos qui additionne les valeurs des 2 terminaux FOS et CAV
# Modifiable
def get_additional_columns(programs, *fields):
    data = {}
    total = get_fos_total(programs, *fields)
    for date,row in total.data.items():
        data[date]={}
        data[date]['total_FOS'] = {}
        for f in fields:
            data[date]['total_FOS'][f] = row[f]
    return data

# Renvoie les colonnes demandées de data mais sous un format spécifique à l'affichage en graphique (chrtjs)
# Champ { Programmes { [dates] } }
def get_graph_datasets(programs, *fields):
    data = {}
    for f in fields:
        for progName,program in programs.items():
            for date in sorted(program.data.keys()):
                row = program.data[date]
                if not f in data:
                    data[f] = {}
                if not progName in data[f]:
                    data[f][progName] = []
                data[f][progName].append(row[f])
    return data

# Renvoie les dates pour l'axe horizontal du graphique chartjs
def get_labels(programs):
    if len(programs) > 0:
        prog = list(programs.values())[0]
        return [prog.data[x]['date'] for x in list(sorted(prog.data.keys()))]
    else:
        return []

# Permet de fusionner 2 programmes en concaténant les données des 2 tableaux data
# Actuellement les données d'en-tête sont celles du programme 1, mais on pourrait imaginer les fusionner proprement en parsant les champs
def join(prog1, prog2):
    if prog1 != None:
        prog = deepcopy(prog1)
        if prog2 != None:
            for day,row in prog2.data.items():
                prog.data[day] = row
        return prog
    elif prog2 != None:
        prog = deepcopy(prog2)
        return prog
    else:
        return None

# Renvoie un tableau d'objets programmes qui correspondent aux premiers programmes qui respectent la date et le terminal demandé dans la liste
# SortedProgramFiles est une liste supposée triée, donc on obtiendra automatiquement la version la plus récente
def get_programs(sortedProgramFiles, terminaux, startDate, stopDate, return_file=False):
    programs ={}
    full_programs = {}
    finalProgram = None
    # Si les deux dates sont sur 2 mois différents, on va avoir besoin de chercher 2 programmes
    if (stopDate.month != startDate.month or startDate.year != stopDate.year):
        for terminal in terminaux:
            # Récupération des 2 fichiers programmes
            progName1 = ProgramFile.find_program(sortedProgramFiles, terminal, startDate, check_timestamp=False)
            progName2 = ProgramFile.find_program(sortedProgramFiles, terminal, stopDate, check_timestamp=False, creation_date=startDate)
            program1, program2 = None, None
            full_programs[terminal] = []
            # Construction des objets programmes
            if progName1 != None:
                program1 = parse_program(progName1)
                full_programs[terminal].append(program1)
            if progName2 != None:
                program2 = parse_program(progName2)
                full_programs[terminal].append(program2)
            # Fusion des deux programmes
            finalProgram = join(program1, program2)
            if finalProgram != None:
                finalProgram.fill_data(startDate, stopDate)
                finalProgram.filter_data(startDate, stopDate)
                programs[finalProgram.program_number] = finalProgram
    # Si les jours demandés rentrent dans 1 mois, on n'a besoin que d'un programme
    else:
        # Meme procédure
        for terminal in terminaux:
            # Récupération du fichier
            progName = ProgramFile.find_program(sortedProgramFiles, terminal, startDate, check_timestamp=False)
            full_programs[terminal] = []
            if progName != None:
                # Construction de l'objet programme
                finalProgram = parse_program(progName)
                full_programs[terminal].append(finalProgram)
                finalProgram.fill_data(startDate, stopDate)
                finalProgram.filter_data(startDate, stopDate)
                programs[finalProgram.program_number] = finalProgram

    return programs, full_programs

# Appelle le constructeur Program avec le upload folder en parametre
def parse_program(program_file):
    s3_credentials = current_app.config["S3_CREDENTIALS"]
    session = Session(
        aws_access_key_id=s3_credentials['ACCESS_KEY'],
        aws_secret_access_key=s3_credentials["SECRET_ACCESS_KEY"])
    s3 = session.client('s3')
    source_file = s3.get_object(Bucket=s3_credentials['BUCKET_NAME'], Key=program_file.filename)['Body'].read()

    #path = current_app.config['UPLOAD_FOLDER']
    if program_file != None:
        #return Program(path, program_file)
        return Program(source_file=source_file, program_file=program_file)
    else:
        return None

# Calcule les totaux des volumes et valeurs énergétiques pour FOS et CAV
def get_fos_total(programs, *fields):
    total = Program()
    cav = [v for k,v in programs.items() if v.terminal=='Fos Cavaou']
    fos = [v for k,v in programs.items() if v.terminal=='Fos Tonkin']
    if (len(cav)>0 and len(fos)>0):
        for date,c in cav[0].data.items():
            f = fos[0].data[date]
            total.data[date] = init_data_row(
                date=c['date']
            )
            for field in fields:
                if (c[field] != "" and f[field]!=""):
                    total.data[date][field] = str(int(c[field]) + int(f[field]))
                else:
                    total.data[date][field] = ""
    return total
