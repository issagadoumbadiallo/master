import re, datetime
from flask import current_app
from boto3.session import Session

# Classe représentant un nom de fichier CSV d'entrée parsé

class ProgramFile:
    def __init__(
        self,
        terminal="",
        year="",
        value="",
        date=None,
        horodatage=None,
        temperature="",
        filename=""
    ):
        self.terminal = terminal
        self.year = year
        self.value = value
        self.date = date
        self.horodatage = horodatage
        self.temperature = temperature
        self.filename = filename


    def toString(self):
        return self.terminal + " / " + str(self.date) + " / " + self.value + " / " + str(self.horodatage) + " / " + self.temperature

# Renvoie un objet ProgramFile si le nom de fichier d'entrée correspond au format demandé, None sinon
def matches(filename):
    regex = 'export_du_detail_du_programme_physique\.([A-Z]{3})-([0-9]{4})Y([0-9]{4})\.([0-9]{8})\.([0-9]{14})\.(vingt_cinq)\.csv'
    p = re.match(regex, filename)
    if p:
        return ProgramFile(
            terminal=p.group(1),
            year = p.group(2),
            value=p.group(3),
            date=datetime.datetime.strptime(p.group(4), "%Y%m%d"),
            horodatage=datetime.datetime.strptime(p.group(5), "%Y%m%d%H%M%S"),
            temperature=p.group(6),
            filename=filename
        )
    else:
        return None

# Trie une liste de noms de fichiers en fonctions de leurs informations (par terminal, puis par date, puis par identifiant)
def sort_programs(filenames):
    programs = []
    for filename in filenames:
        parsedFile = matches(filename)
        if parsedFile != None:
            programs.append(parsedFile)
    programs.sort(key=lambda x: (x.terminal, x.date.year, x.date.month, x.value), reverse=True)
    return programs

# Renvoie le premier programme qui correspond aux paramètre d'entrée dans la liste triée
def find_program(programs, terminal, date, check_timestamp=False, creation_date=None):
    for p in programs:
        if p.terminal == terminal:
            if p.date.year == date.year:
                if p.date.month == date.month:
                    if check_timestamp is True:
                        if creation_date is None:
                            creation_date = date
                        if datetime.datetime(p.horodatage.year, p.horodatage.month, p.horodatage.day-1) <= creation_date:
                            return p
                    else:
                        return p
    return None

def get_programs_filenames():
    s3_credentials = current_app.config["S3_CREDENTIALS"]
    session = Session(
        aws_access_key_id=s3_credentials['ACCESS_KEY'],
        aws_secret_access_key=s3_credentials["SECRET_ACCESS_KEY"])
    s3 = session.resource('s3')
    bucket = s3.Bucket(s3_credentials['BUCKET_NAME'])
    filenames = []
    for prog_file in bucket.objects.all():
        filenames.append(prog_file.key)
    return filenames