import functools

from .auth import login_required

from flask import (
    Blueprint, flash, jsonify, current_app, g, redirect, render_template, request, session, url_for
)
from werkzeug.security import check_password_hash, generate_password_hash

from boto3.session import Session


###

from random import randint
import os, re, glob, datetime

from . import Program, ProgramFile

###

bp = Blueprint('index', __name__, url_prefix='/')

@bp.route('/', methods=('GET', 'POST'))
@login_required
def index():
    # start, stop et delta permettent de mesure le temps de traitement
    #start = datetime.datetime.now()
    
    terminaux = ['MON', 'FOS', 'CAV']
    programs = {}
    now = datetime.date.today()
    date = datetime.datetime(now.year, now.month, now.day)
    
    '''
    # Décommenter pour donner la possibilité de choisir une date en requête POST
    if request.method=='POST':
        date = datetime.datetime.strptime(request.form.get('date'), '%Y-%m-%d')
    '''
    
    startDate = date - datetime.timedelta(days=1)
    stopDate = date + datetime.timedelta(days=21)
    
    # Récupération de la liste des programmes triés par date et identifiants
    filenames = ProgramFile.get_programs_filenames()
    '''
    # Récupération des fichiers en local
    sortedProgramFiles = ProgramFile.sort_programs(os.listdir(current_app.config['UPLOAD_FOLDER']))
    '''
    # Récupération des fichiers sur S3
    sortedProgramFiles = ProgramFile.sort_programs(filenames)
    
    # Récupération des programmes pour chaque terminal
    programs, full_programs = Program.get_programs(sortedProgramFiles, terminaux, startDate, stopDate)
    # Récupération des dates pour le graphique
    labels = Program.get_labels(programs)
    
    #stop = datetime.datetime.now()
    #delta = stop - start
    #print("Durée totale de traitement : " + str(float(delta.microseconds) / 1000000))
    
    return render_template('index/index.html',
    terminaux=terminaux,
    datasets=adjust_units(Program.get_data(programs, 'daily_energy', 'daily_gaz_volume', 'daily_gnl_volume')),
    additional_columns=adjust_units(Program.get_additional_columns(programs, 'daily_energy', 'daily_gaz_volume', 'daily_gnl_volume')),
    graphDatasets=adjust_graph_units(Program.get_graph_datasets(programs, 'daily_energy', 'daily_gaz_volume', 'daily_gnl_volume')),
    labels=labels,
    date=datetime.datetime.strftime(date, '%d/%m/%Y'),
    programs=programs,
    full_programs=full_programs
    )

# Ajuste les données de certaines colonnes en les divisant selon l'unité
def adjust_units(datasets):
    for day,prog in datasets.items():
        for progName,program in prog.items():
            for field,data in program.items():
                if field == 'daily_energy' or field == 'daily_gaz_volume':
                    datasets[day][progName][field] = divide_string(data, 1000000, replace_dots=True)
    return datasets

# Ajuste les données du graphique en les divisant
def adjust_graph_units(datasets):
    for field,prog in datasets.items():
        for progName,program in prog.items():
            for day in range(len(program)):
                if field == 'daily_energy' or field == 'daily_gaz_volume':
                    datasets[field][progName][day] = divide_string(datasets[field][progName][day], 1000000)
    return datasets

# Les données sont stockées en String, donc il faut les convertir, les diviser, les arrondir et renvoyer un nouveau string
def divide_string(data, div, replace_dots=False):
    if data != "":
        # TODO : Gérer les nombres à virgule correctement
        # Peut etre remplacer les virgules par des points avant
        # Ou bien il y a une méthode pour parser du float sur des nombres a virgules et pas avec points
        try:
            if replace_dots==False:
                data = str(round((float(data) / div), 1))
            else:
                data = str(round((float(data) / div), 1)).replace('.',',')
        except:
            return data 
    return data

def string_to_date(date):
    parse = re.search('([0-9]{4})-([0-9]{2})-([0-9]{2})', date)
    if parse:
        return parse.group(1), parse.group(2), parse.group(3)
    return None