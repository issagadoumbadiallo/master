from flask import Blueprint, url_for, session, jsonify, Flask, render_template, redirect, request, current_app
from werkzeug import secure_filename
from functools import wraps
import os

app = Flask(__name__)

bp = Blueprint('auth', __name__, url_prefix='/auth/')

@bp.route('/', methods = ['GET', 'POST'])
def login():
    return render_template('auth/login.html')

@bp.route('/login', methods = ['GET', 'POST'])
def verify_login():
    if request.method == 'POST':
        bd = {'terminaux':'terminauxcallisto'}
        # Faire la avérification FARO
        usr = request.form.get('username')
        pwd = request.form.get('password')
        if bd[usr] == pwd:
            session['username'] = usr
            return redirect(url_for('index.index'))
        else:
            return render_template('auth/login.html', error="Mauvais identifiant ou mot de passe")
    else:
        return redirect(url_for('auth.login'))

def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'username' not in session:
            return redirect(url_for('auth.login'))
        return f(*args, **kwargs)
    return decorated_function