import functools

from flask import (
    Blueprint, jsonify, flash, current_app, g, redirect, render_template, request, session, url_for
)
from werkzeug.security import check_password_hash, generate_password_hash

###

from random import randint
import os, re, glob, datetime, json

from . import Program, ProgramFile
from . import index as i

###

bp = Blueprint('api', __name__, url_prefix='/api/')


@bp.route('/')
@bp.route('/<int:day>-<int:month>-<int:year>')
def index(day=None, month=None, year=None):
    terminaux = ['MON', 'FOS', 'CAV']
    programs = {}
    datasets = {}
    
    if day==None or month==None or year==None:
        startDate = datetime.datetime.today()
    else:
        startDate = datetime.datetime(year, month, day)
    stopDate = startDate + datetime.timedelta(days=5)

    sortedProgramFiles = ProgramFile.sort_programs(os.listdir(current_app.config['UPLOAD_FOLDER']))
    programs, full_programs = Program.get_programs(sortedProgramFiles, terminaux, startDate, stopDate)

    datasets = Program.get_graph_datasets(programs, 'daily_energy')
    labels = Program.get_labels(programs)
    data = {}
    data['dates'] = labels
    data['data'] = datasets
    data['imports'] = {}
    for k,v in programs.items():
        data['imports'][k] = v.program_file.horodatage
            
    return jsonify(data)