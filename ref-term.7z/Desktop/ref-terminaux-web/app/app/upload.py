from flask import Blueprint, jsonify, Flask, render_template, redirect, request, current_app
from werkzeug import secure_filename
import os
from boto3.session import Session
from . import ProgramFile
import datetime
import json

app = Flask(__name__)

bp = Blueprint('upload', __name__, url_prefix='/upload/')

@bp.route('/', methods = ['GET', 'POST'])
def upload_file():
    if request.method == 'POST':
        files = request.files.getlist('file[]')
        s3_credentials = current_app.config["S3_CREDENTIALS"]
        session = Session(
                aws_access_key_id=s3_credentials['ACCESS_KEY'],
                aws_secret_access_key=s3_credentials["SECRET_ACCESS_KEY"])
        s3 = session.resource('s3')
        bucket = s3.Bucket(s3_credentials['BUCKET_NAME'])
        for f in files:
                bucket.put_object(Key=secure_filename(f.filename), Body=f)
                #f.save(os.path.join(current_app.config['UPLOAD_FOLDER'], secure_filename(f.filename)))
        # TODO : Vérifier dans le bucket si le fichier est bien la

        # TODO : Verifier si on remplace pas un fichier

        clean_programs()

        return redirect("/")

def find_programs_to_keep(programs):
        programs_to_keep = {}
        for p in programs:
                date_str = p.terminal + datetime.datetime.strftime(p.date, "%Y%m%d") 
                if date_str not in programs_to_keep:
                        programs_to_keep[date_str] = p
                else:
                        if int(p.value) > int(programs_to_keep[date_str].value) and p.horodatage > programs_to_keep[date_str].horodatage:
                                programs_to_keep[date_str] = p
        return list(programs_to_keep.values())
        

def clean_programs():
        s3_credentials = current_app.config["S3_CREDENTIALS"]
        session = Session(
                aws_access_key_id=s3_credentials['ACCESS_KEY'],
                aws_secret_access_key=s3_credentials["SECRET_ACCESS_KEY"])
        s3 = session.resource('s3')

        sorted_programs = ProgramFile.sort_programs(ProgramFile.get_programs_filenames())
        to_keep =  find_programs_to_keep(sorted_programs)
        filenames_to_keep = list(map(lambda x: x.filename, to_keep))
        client = session.client('s3')
        current_files = client.list_objects(Bucket=s3_credentials["BUCKET_NAME"])
        for d in current_files["Contents"]:
                if ProgramFile.matches(d['Key'])==None or d["Key"] not in filenames_to_keep:
                        client.delete_object(Bucket=s3_credentials['BUCKET_NAME'], Key=d['Key'])